package com.app.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "tb_veiculo")
public class Veiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String placa;

    @Column
    private Integer ano;

    @Column
    private Integer matricula;

    @Column
    private String marca;

    @Column
    private String modelo;

    @Column
    private String propietario;

    @Column
    private Boolean alugado;

}
